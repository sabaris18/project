export class ViewDonation{
    UserName:string;
    ContactNumber:string;
    CategoryName:string;
    Description:string;
    DonationDate:Date;
}