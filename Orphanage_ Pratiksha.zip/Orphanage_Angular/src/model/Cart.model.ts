export class Cart{
    CartID:number;
    UserID:number;
    ProductID:number;
}