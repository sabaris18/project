export class ResponseMessage{
    Message:string;
}