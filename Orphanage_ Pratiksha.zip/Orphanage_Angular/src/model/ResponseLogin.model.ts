export class ResponseLogin{
    UserID:string;
    EmailID:string;
    Message:string;
}