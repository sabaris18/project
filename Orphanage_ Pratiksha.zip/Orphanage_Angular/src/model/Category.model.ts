export class Category{
    CategoryID:number;
    CategoryType:string;
    CategoryName:string;
}