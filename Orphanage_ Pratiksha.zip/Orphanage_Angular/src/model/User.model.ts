export class User{
    UserID:number;
    FirstName:string;
    LastName:string;
    EmailID:string;
    Gender:string;
    ContactNumber:string;
    Address:string;
    Password:string;
    UserType:string;
    Flag:number;
}