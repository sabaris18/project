export class Books{
    BookID:number;
    CategoryID:number;
    Description:string;
    DonationDate:Date;
}