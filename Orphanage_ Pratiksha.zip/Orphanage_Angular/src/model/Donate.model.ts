export class Donate{
    DonationID:number;
    CategoryID:number;
    Description:string;
    DonationDate:Date;
    UserID:number;
}