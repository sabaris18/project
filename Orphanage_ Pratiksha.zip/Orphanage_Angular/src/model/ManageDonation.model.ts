export class ManageDonation{
    ManageDonationID:number;
    DonationName:string;
    DonationImage:string;
    RouterLink:string;
    Flag:number;
}